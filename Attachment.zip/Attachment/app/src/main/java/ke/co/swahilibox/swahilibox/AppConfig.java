package ke.co.swahilibox.swahilibox;

/**
 * Created by japheth on 11/15/15.
 */
public class AppConfig {

    public static final String PARSE_CHANNEL = "SwahiliBox";

    //aplication id and client_key for use in development mode
    public static final String PARSE_APPLICATION_ID = "yzS7r0SVjb0r6zdZEKviYrHr5UbypxzNrO236uOH";
    public static final String PARSE_CLIENT_KEY = "Eztcb8WvOdx74ah93YNZfC4QejtcgBjvyqYAfIMX";
    public static final int NOTIFICATION_ID = 100;
}
